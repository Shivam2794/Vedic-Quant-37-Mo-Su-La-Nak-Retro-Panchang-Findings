# ETERNAL QUANT REGIME ENGINE (AG Plug-and-Play Package)
=========================================================

This package contains the triumphant discovery and live institutional architecture derived from **6,731 deep-mined quantitative literature items** and **46 years of out-of-sample backtest verification** across all 20 historical US market crashes (1980–2026), synthesized by **OpenRouter Claude Fable 5 (`~anthropic/claude-fable-latest`)**.

## 📦 What's Included in This Discovery Package

1. **`eternal_quant_regime_engine.py`**: The standalone Python engine that implements Fable's 3-Block Confirmation Stack and Conditional Severity Model.
2. **`universal_crash_dataset.parquet`**: The 46-year daily multi-asset dataset (11,722 rows x 44 symbols) containing all necessary factor ratios, credit spreads, carry pairs, and volatility term structures.
3. **`fable_literature_aggregation_analysis.md`**: Fable's complete institutional hostile audit, structural decay matrix, taxonomy, and mathematical architecture brief.
4. **`universal_crash_hall_of_fame.md`**: The empirical out-of-sample verification leaderboard of our top 492 derived ratio rules.

---

## 🚀 How to Drop This Into Any Other AG Quant Project

Simply copy `eternal_quant_regime_engine.py` (and optionally `universal_crash_dataset.parquet`) into your target project directory and import it into your trading strategies, portfolio optimizers, or backtesting scripts:

```python
from eternal_quant_regime_engine import QuantRegimeDetector

# Initialize the detector (automatically loads the bundled parquet or live data)
detector = QuantRegimeDetector()

# Get the real-time institutional regime and trading advice
live_state = detector.detect_regime()

print(live_state["regime"])                 # e.g., "CALM / BULL REGIME" or "STRUCTURAL_CRASH_ALERT"
print(live_state["crash_probability_pct"])  # e.g., 5.0% or 85.0%
print(live_state["recommended_hedge_ratio"])# e.g., 0.0 (unhedged) or 1.0 (100% hedged)
print(live_state["action_advice"])          # Actionable instructions for alpha allocation

# Check which Fable confirmation blocks are actively firing:
blocks = live_state["blocks_firing"]
if blocks["Block_A_Credit"]:
    print("Warning: High Yield credit spread acceleration detected!")
if blocks["Arming_Defensive_Rotation"] and not blocks["Block_A_Credit"]:
    print("High-EV Opportunity: Buyable Contrary Correction (<10%)!")
```

---

## 🏛️ Core Architectural Logic (Fable 3-Block Stack)

Instead of relying on single noisy indicators, this engine uses Fable's **3-Block Confirmation Stack**:
* **Arming Layer (Yellow Alert)**: Defensive factor rotations (`SPLV/SPY`, `XLP/XLY`, `USMV/SPY`). High sensitivity, high lead time.
* **Block A (Credit & Funding Stress)**: High Yield OAS spread acceleration (`HYG/LQD`, `LQD/TLT`).
* **Block B (Macro Growth Divergence)**: Industrial commodity collapse (`Copper/Gold` ROC < -8%) + Yield Curve bull steepening.
* **Block C (Cross-Asset Risk Transfer)**: Carry unwind (`AUD/JPY` break) + VIX persistent backwardation (`VIX > VIX3M` for >=4 of 5 days).

### Decision Rules for Your Strategy:
1. **$\ge 2$ Confirmation Blocks Active** $\rightarrow$ **Structural Crash Alert ($>10\%$ drawdown)**. Cut gross exposure / execute tail hedges.
2. **Arming Active + $0$ Confirmation Blocks + VIX Re-normalizing** $\rightarrow$ **Buyable Contrary Correction ($<10\%$)**. Execute contrarian long with defined risk.
3. **All Blocks Calm** $\rightarrow$ **Bull Regime**. Maintain full quantitative alpha exposure.
