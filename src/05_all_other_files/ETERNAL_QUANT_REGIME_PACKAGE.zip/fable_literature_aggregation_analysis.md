# OPENROUTER FABLE (CLAUDE FABLE 5) QUANTITATIVE SYNTHESIS & USABILITY ARCHITECTURE

## 🧠 FABLE'S STEP-BY-STEP INTERNAL REASONING
```
I'm identifying some serious methodological flaws here: the dataset appears contaminated with irrelevant papers across domains, the ETF inception dates don't align with the historical period being tested (SPLV and USMV only launched in 2011, which creates survivorship bias for the earlier crashes), and running 492 different rules introduces severe multiple testing problems. The lead times of 120-160 days also seem unrealistically long and suggest the apparent signal might just be capturing delayed market reactions rather than genuine predictive power.

A critical insight emerges around the denominator contamination issue — any ratio rule using SPY as the denominator is essentially just detecting SPY weakness, which becomes self-referential when trying to predict SPY crashes. The signal windows and crash windows overlap so extensively across the 46-year period that false positives become almost inevitable by construction. I should also scrutinize the literature mining process, which seems polluted with irrelevant papers (tobacco packaging, agricultural robots, climate reports) that don't belong in financial domain buckets. The retrieval needs filtering with embedding relevance scores and financial NLP classifiers rather than relying on citation counts and keyword matching.

For the mathematical architecture, I'm considering regime-switching models like HMMs, Bayesian fusion with log-odds pooling, López de Prado's meta-labeling framework, and changepoint detection methods. The key is building a confirmation stack across orthogonal blocks — macro indicators, liquidity stress (credit spreads, funding conditions), and breadth metrics — to distinguish genuine crashes from mere corrections. I need to account for modern regime decay too: index concentration has warped traditional relationships, and sector definitions are breaking down (utilities now tied to AI data center power demand rather than defensive rotation).
```

---

## 📊 FINAL ACTIONABLE SYNTHESIS & USABILITY MATRIX

# FABLE STRUCTURAL AUDIT & ARCHITECTURE BRIEF
## Crash-Prediction Factory: Validation Critique, Regime Analysis, Taxonomy, and Live Engine Design

---

# 1. NOISE VS. SIGNAL: A HOSTILE AUDIT OF YOUR METHODOLOGY

Before praising a 95% accuracy number, a CRO's job is to try to kill it. Here is how it dies — and what survives.

## 1.1 Fatal and Near-Fatal Methodological Defects

**(a) Denominator contamination — the self-referential ratio problem.**
Your #1 champion is `DXY/SPY > 20d SMA by 3%`. Decompose it:

$$\frac{d}{dt}\ln\left(\frac{DXY_t}{SPY_t}\right) = \frac{d}{dt}\ln DXY_t - \frac{d}{dt}\ln SPY_t$$

A 3% breach above a 20-day SMA is dominated by the **SPY leg falling**, not by dollar strength. The same applies to *every* `X/SPY` rule (XLU/SPY, SPLV/SPY, XLP/XLY partially, RUT/SPY). You are, to a first approximation, detecting that **the market has already started going down** and then claiming you "predicted" the drawdown trough. This is not a leading indicator; it is a *trend-following filter rebranded as a forecast*. The honest test: regress each signal's trigger dates against a naive `SPY < 20d SMA by 3%` rule. If the trigger correlation exceeds ~0.7, your alpha is a momentum filter, and the correct benchmark is a simple 200-day moving average rule (Faber 2007), not a null of random guessing.

**(b) ETF inception misalignment / epoch cherry-picking.**
SPLV (2011), USMV (2011), HYG (2007), sector SPDRs (1998). Rules tested on "7/8" or "10/11" crashes are being evaluated only on the **post-2007 QE-dominated regime** — a single macro regime with correlated crash morphology (liquidity-driven, Fed-reactive, V-shaped). Comparing an 8-crash rule's composite score against a 20-crash rule's score on the same leaderboard is statistically incoherent. Fix: (i) evaluate only on epochs where the instrument exists, (ii) **backfill with underlying indices** (S&P 500 Low Vol index → 1990, Merrill HY index OAS → 1996, sector total-return indices → 1989), (iii) report per-epoch stratified metrics, never pooled.

**(c) Multiple testing: 492 rules is a p-hacking machine.**
With ~20 events, the effective sample size for a binary classifier is tiny. Under Bonferroni, your per-rule significance threshold is α/492 ≈ 1.0×10⁻⁴. Almost nothing with n=8–13 events survives that. The correct machinery:

- **White's Reality Check / Hansen's SPA test** across the full rule universe against a data-mined null.
- **Stationary block bootstrap** (Politis–Romano, block length ~63 days to preserve volatility clustering) of the SPY path; recompute each rule's composite score on 10,000 pseudo-histories; a rule is real only if its actual score exceeds the 99th percentile of its bootstrap distribution *after* rank-adjusting for selection (deflated statistics à la Bailey–López de Prado's **Deflated Sharpe Ratio** and **PBO via CSCV**).
- **Effective number of independent rules**: your 492 rules cluster into perhaps 8–12 orthogonal factors (defensive rotation, credit, carry, dollar, industrial metals, breadth, vol structure). Compute the eigenvalue spectrum of the rule-signal correlation matrix; Bonferroni on N_eff ≈ 10, not 492 — this is the *charitable* correction, and even it will kill half the leaderboard.

**(d) The lead-time/base-rate confound.**
Average lead times of 120–160 trading days are a red flag, not a feature. With 20 events in 46 years and a "caught if fired within ~150 days pre-trough" window, your admissible-hit windows cover roughly **25–40% of all trading days**. A random Bernoulli signal firing at your observed frequency would "catch" a large fraction of crashes by construction. You must report the **hazard-ratio uplift**: P(crash within h days | signal) / P(crash within h days unconditionally), with h ∈ {21, 63, 126}. If uplift < 3× at h=63, the rule is noise. Also define "false alarm rate" precisely — per-day, per-episode, or per-cluster of consecutive triggers? Consecutive daily triggers are one alarm, not 40.

**(e) The literature mine is contaminated.**
Be blunt with yourselves: your keyword-harvest pipeline is polluted. "Dark pool short sale volume" returned tobacco-packaging Cochrane reviews; "consumer staples XLP/XLY" returned mixed-reality robot games; "smart money flow" returned smart-farming IoT platforms; "DXY liquidity drain" returned a vortex-drain metaheuristic. Roughly **30–40% of your 6,731 items are semantically irrelevant** — keyword collision, not domain knowledge. Fix: embed abstracts (finance-tuned encoder), score cosine similarity against a curated seed corpus (Estrella–Mishkin, Adrian–Boyarchenko–Giannone, Chauvet–Piger, Baron–Verner–Xiong, Brunnermeier 2009), and hard-filter below threshold. Citation counts are meaningless across fields — normalize within-field or drop them.

## 1.2 The Frequency/Severity Dilemma: Structural Break vs. Buyable Correction

The core insight from your own archive (Baron–Verner–Xiong 2020; Adrian et al. GaR; Brunnermeier 2009; Kaminsky–Reinhart–Végh contagion) is that **corrections are volatility events; crashes are credit-and-funding events.** A >10% structural break virtually never occurs without the financial sector's balance sheet being impaired. This gives you a clean discrimination architecture:

**The Three-Block Confirmation Stack (fire ≥2 of 3 blocks to classify as structural):**

| Block | Indicators (from your archive) | What a *correction* looks like | What a *crash* looks like |
|---|---|---|---|
| **A. Credit & Funding** | HY OAS Δ, HYG/LQD, LQD/TLT, FRA-OIS (TED successor), CP spread, NFCI, STLFSI | Spreads widen <75bp, funding calm | OAS +150bp+ and accelerating; funding spreads blow out; NFCI crosses 0 |
| **B. Macro Growth** | Copper/Gold ROC, yield curve *un-inversion* (bull steepening), Chauvet–Piger P(recession), PMI <48, Sahm-rule proximity | Macro nowcast stable | Copper/gold collapse + curve bull-steepening + CP probability >30% |
| **C. Cross-Asset Risk Transfer** | AUD/JPY carry break, DXY surge (genuine, i.e., DXY level breakout — *not* DXY/SPY), VIX term-structure inversion (VIX > VIX3M) persisting >5 days, SKEW→VIX handoff | Vol spikes and term structure re-normalizes in <5 sessions | Carry unwind + persistent backwardation + dollar squeeze simultaneously |

**Decision rule:** Your defensive-rotation triggers (XLP/XLY, XLU/SPY, SPLV/SPY) are the **arming layer** — high sensitivity, high lead time, mediocre specificity. They put you in "yellow." You only go to "red" (hedge/short, cut gross, buy tail structures) when ≥2 confirmation blocks fire within a 21-day window of each other. Conversely: **arming signal + zero block confirmation + VIX term structure re-normalizing within 5 sessions = buyable correction** — that combination has historically been the single best contrarian long entry (1998 post-LTCM, 2011, 2018 Q4, 2020 recovery leg).

Quantitatively: the correction-vs-crash classifier is a **conditional severity model** — estimate P(drawdown > 10% | armed) via logistic regression on the block scores, or better, quantile regression on forward 63-day returns (the GaR framework from your Adrian–Boyarchenko–Giannone domain applied to equities: model the **5th percentile of the forward return distribution** as a function of NFCI + credit + carry; hedge when the left tail lengthens, not when the median dips).

---

# 2. STRUCTURAL REGIME DECAY IN THE AI/MEGA-CAP ERA

## 2.1 Why classical ratios are decaying

1. **Index concentration & inelastic markets.** Top-10 names ≈ 35%+ of the S&P 500. Every `X/SPY` ratio now embeds a short-mega-cap-tech position. XLB/SPY or RUT/SPY "breakdowns" since 2015 partly measure *the AI capex trade working*, not credit stress. Gabaix–Koijen inelastic-markets logic: passive flows amplify concentration and mute breadth signals — advance/decline divergences fired near-continuously 2023–2024 with no crash.
2. **XLU is no longer defensive.** Utilities are now an AI-power-demand growth trade (data-center electricity). Rule #14/#16 (XLU/SPY surge = crash warning) will generate structurally elevated false alarms going forward. Same partially true for XLP margins under retail-media monetization.
3. **Copper/Gold is doubly distorted**: copper demand is increasingly AI/grid/EV-structural (see your Nassar et al. mineral supply-risk paper), while gold is bid by central-bank de-dollarization flows independent of growth fear. The ratio's denominator now carries a *debasement premium*, not just a risk premium. Re-calibrate against a broader industrial basket (copper+aluminum)/(gold+CHF) or use it only as a slow macro block input.
4. **Yield curve semantics changed.** QE/QT, RRP/TGA plumbing (your dedicated domain) mean term premium is policy-administered. Estrella–Mishkin inversion still contains information but lead times stretched (2022 inversion → no 2023 recession). The tradable variant is **un-inversion via bull steepening** — that timing signal remains intact.
5. **0DTE and vol-supply regime.** ~50%+ of SPX option volume in 0DTE flattens VIX's information content: dealers' intraday gamma pins spot, VIX stays suppressed while fragility accumulates (dispersion at record wides, index vol sold structurally). Classic "low VIX = complacency" thresholds must be replaced by **VIX term-structure shape, VVIX/VIX, SKEW dynamics, and dealer gamma positioning estimates**.

## 2.2 Immunity ranking of your mined domains

| Robust (structurally invariant) | Requires re-calibration | Structurally broken / retire |
|---|---|---|
| Dollar/global-liquidity drain (genuine DXY, cross-currency basis) — dollar is still the world's margin call | Copper/gold (industrial demand shift) | XLU/SPY defensive logic (AI power trade) |
| Credit spreads: HY OAS, HYG/LQD, LQD/TLT — leverage is eternal; but watch stress migrating to **private credit** (unobserved) | Yield curve (use un-inversion + steepening speed) | Simple P/E, Dow Theory transports confirmation (freight ≠ digital economy) |
| Funding stress: FRA-OIS, CP spreads, NFCI, RRP/TGA drainage | Breadth/A-D lines (concentration distortion — condition on equal-weight vs cap-weight spread) | Baltic Dry as US equity signal (China/supply-driven) |
| Carry unwind AUD/JPY, now **USD/JPY + yen-funded AI-trade leverage** (Aug 2024 proof-of-concept) | Put/call ratios (0DTE contamination — use delta-weighted, non-0DTE only) | Margin debt (FINRA data lags; leverage moved to options/swaps/pod funds) |
| Chauvet–Piger / GaR frameworks (methodology, not fixed inputs) | SKEW (structural risk-premium drift; use z-scores vs 2y window) | Smart Money Flow Index (MOC/passive flow artifact) |

---

# 3. MASTER USABILITY TAXONOMY

| Category | Rationale | Lead Time | False-Alarm Character & Filter | Modern Usability |
|---|---|---|---|---|
| **I. Slow Macro-Liquidity Early Warning** (DXY, RRP/TGA, global M2, NFCI, PMI, copper/gold, Chauvet–Piger) | Liquidity withdrawal precedes deleveraging; dollar is global funding currency | **60–180 trading days** | Fires in soft patches; filter with GaR left-tail estimate & require credit confirmation | HIGH (plumbing matters more than ever post-QE) — this is your **arming layer** |
| **II. Credit & Funding Stress** (HY OAS, HYG/LQD, LQD/TLT, CP spread, FRA-OIS, SRISK, bank equity per Baron–Verner–Xiong) | Crashes are balance-sheet events; intermediary capital is the marginal pricer | **20–90 days** | Low false-alarm when using *acceleration* (ΔOAS > +75bp/21d), not level | HIGH, but blind spot = private credit; supplement with BDC prices & bank CDS |
| **III. Cross-Asset Carry/Risk-Transfer** (AUD/JPY, USD/JPY, EM FX, gold/oil, cross-currency basis) | Funding-currency unwinds force mechanical de-grossing across all risk | **10–60 days** | Moderate; filter by requiring simultaneity across ≥2 pairs + basis widening | HIGH — yen-funded AI leverage makes this *more* relevant (Aug 2024) |
| **IV. Defensive Factor/Sector Rotation** (XLP/XLY, SPLV/SPY, USMV/SPY, XLV/SPY) | Institutions rotate before they sell; low-vol bid = falling risk appetite | **60–140 days** | HIGH false-alarm standalone; also value/growth style-cycle contamination; use only as arming, drop XLU | MEDIUM — must be concentration-adjusted (equal-weight versions) |
| **V. Volatility Term Structure & Tail Pricing** (VIX/VIX3M, VIX9D/VIX, VVIX, SKEW, dealer gamma) | Vol backwardation = demand for immediate protection = smart-money urgency | **0–20 days** | Frequent 1–3 day inversions are noise; filter = **persistence ≥5 sessions** + VVIX confirmation | HIGH but re-thresholded for 0DTE-era; the **timing/trigger layer** |
| **VI. Contagion / Microstructure Fast Detection** (breadth collapse, NH-NL surge, correlation spikes, Hawkes-process trade clustering, liquidity depth) | Fire-sale dynamics are self-exciting; correlation → 1 in crises (Forbes, Kaminsky et al.) | **0–10 days** | Corrections look identical initially; use for *execution sequencing*, not prediction | HIGH for risk management, useless for forecasting |
| **VII. Sentiment/Positioning Extremes** (put/call, COT, NLP news tone, margin proxies) | Behavioral overextension (Shiller) precedes fragility but not timing | **Unbounded/vague** | Extreme false-alarm; use only as a **prior/vulnerability score**, never a trigger | LOW-MEDIUM; NLP on Fed/earnings-call language is the salvageable piece |
| **VIII. Bubble Diagnostics** (LPPLS/Sornette log-periodicity, Case–Shiller-style valuation dislocation, Cutler–Poterba–Summers speculative dynamics) | Super-exponential price growth with hazard-rate signature | **20–120 days, wide CI** | Notorious false positives; use as regime-conditioning variable only | MEDIUM — apply to AI-capex-linked names specifically |

**Usage doctrine:** I & IV **arm**; II & III **confirm**; V **triggers**; VI **manages execution**; VII & VIII **set the prior**.

---

# 4. LIVE MULTI-REGIME FUSION ENGINE: MATHEMATICAL ARCHITECTURE

## Layer 0 — Labeling (fix this first)
Replace "20 named crashes" with **triple-barrier labels** (López de Prado): for each day t, forward path hits −10% (crash barrier), +5% (recovery barrier), or 126-day vertical barrier first. This converts 20 events into thousands of properly weighted observations and lets you separately label the −5% to −10% "correction" class for the severity model. All CV must be **purged k-fold with embargo** (labels overlap in time).

## Layer 1 — Regime backbone: HMM/MS-DFM
Estimate a dynamic-factor Markov-switching model (Chauvet–Piger, direct from your archive) on a state vector of block factors:

$$X_t = \Lambda f_t + \varepsilon_t, \qquad f_t = \mu_{S_t} + \phi f_{t-1} + \eta_t, \quad \eta_t \sim N(0, \Sigma_{S_t})$$

with S_t ∈ {Calm, Fragile-Bull, Stress, Crisis} (4 states — you need the Fragile-Bull state to capture 2007-mid, 1999, 2021, and the current AI-concentration regime). Hamilton filter gives ξ_t = P(S_t | ℱ_t) causally. Augment with **Bayesian Online Changepoint Detection** on the factor loadings themselves to catch the structural decay of Section 2 (when copper/gold's loading on the growth factor drifts, the engine down-weights it automatically).

## Layer 2 — Block probabilities via Growth-at-Risk quantile regression
For each block b ∈ {Liquidity, Credit, Carry, Rotation, Vol, Contagion}, estimate the conditional forward-return quantile:

$$\hat{Q}_{0.05}(r_{t \to t+63} \mid Z_t^b) = \beta_0 + \beta_b' Z_t^b$$

and convert to a block crash probability p_t^b via the skewed-t fitted distribution (exact ABG methodology, ported to equities). This gives calibrated, distribution-aware block signals rather than binary threshold rules.

## Layer 3 — Correlation-adjusted Bayesian log-odds fusion
Naive Bayes double-counts because blocks II and III are correlated in stress. Fuse in log-odds space with a shrinkage precision weighting:

$$L_t = \lambda_0(\xi_t) + \sum_b w_b(\xi_t)\left[\text{logit}(p_t^b) - \text{logit}(\pi_b)\right], \qquad w = \Sigma_L^{-1}\mathbf{1} \big/ \mathbf{1}'\Sigma_L^{-1}\mathbf{1} \cdot \kappa$$

where Σ_L is the (Ledoit–Wolf shrunk) covariance of block log-odds innovations, π_b are unconditional base rates, and **weights are regime-conditional**: in ξ(Fragile-Bull), rotation/liquidity blocks dominate; once ξ(Stress) > 0.3, credit/carry/vol blocks take over. This is a supra-Bayesian pool that penalizes redundant confirmation.

## Layer 4 — Meta-labeling (the false-alarm killer)
The fused primary signal decides *direction* (get defensive); a secondary gradient-boosted classifier decides *whether to act and how big*, trained on triple-barrier outcomes with features = {L_t, ξ_t, VIX term-structure slope, breadth-of-blocks-firing count, time-since-last-alarm, concentration index, dealer-gamma proxy}. Output → position size via 

$$\text{HedgeRatio}_t = f(\hat{p}^{meta}_t) \cdot \sigma_{target}/\hat{\sigma}_t$$

Meta-labeling is precisely the mathematical formalization of your correction-vs-crash filter: the primary layer catches everything (high recall), the meta layer buys precision.

## Layer 5 — Calibration, monitoring, and kill-switches
- **Isotonic calibration** of final P(crash|ℱ_t) on purged out-of-sample folds; report Brier score and reliability diagrams quarterly.
- **CUSUM monitors on each block's hit-rate** — auto-demote a block whose live precision drops 2σ below backtest (this is how XLU/SPY gets retired without human ego intervention).
- **Hawkes-process intensity** on realized-loss clustering as the Layer-VI fast overlay: if λ_t spikes while P(crash) is high → execute hedges via options *before* liquidity evaporates; if λ_t spikes while P(crash) is low → correction playbook, deploy contrarian long with defined-risk structures.
- **Governance:** every candidate rule entering the factory must pass SPA/deflated-score testing against the full 492-rule search history (maintain the trial registry — the multiple-testing correction is only honest if you count *every* rule you ever tried, including the dead ones).

## Bottom line
Your factory has found one genuinely robust meta-truth — **crashes are preceded by the joint signature of dollar-liquidity drain + credit deterioration + carry unwind + defensive rotation, with rotation leading and vol-structure triggering** — but the leaderboard as presented is unpublishable: denominator-contaminated, epoch-misaligned, multiplicity-unadjusted, and fed by a polluted corpus. Rebuild on triple-barrier labels, hazard-uplift metrics, block-orthogonalized fusion, and meta-labeled sizing, and you convert a data-mined artifact into an institutional-grade regime engine.